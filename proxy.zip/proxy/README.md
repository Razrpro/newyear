# Proxy Server

Прокси-сервер для перенаправления всех запросов на http://razr.freedynamicdns.org:5001/

## Установка

```bash
npm install
```

## Запуск

```bash
npm start
```

Или в режиме разработки с автоперезагрузкой:

```bash
npm run dev
```

По умолчанию сервер запускается на порту 3000. Можно изменить через переменную окружения PORT:

```bash
PORT=8080 npm start
```

## Использование

После запуска все запросы к `http://localhost:3000/*` будут проксированы на `http://razr.freedynamicdns.org:5001/*`
