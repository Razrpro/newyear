const http = require('http');
const httpProxy = require('http-proxy');

const TARGET_URL = 'http://razr.freedynamicdns.org:5001';
const PORT = process.env.PORT || 3000;

// Создаем прокси-сервер
const proxy = httpProxy.createProxyServer({
    target: TARGET_URL,
    changeOrigin: true,
    ws: true // Поддержка WebSocket
});

// Обработка ошибок прокси
proxy.on('error', (err, req, res) => {
    console.error('Proxy error:', err);
    if (!res.headersSent) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
    }
    res.end('Proxy error occurred');
});

// Логирование запросов
proxy.on('proxyReq', (proxyReq, req, res) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url} -> ${TARGET_URL}${req.url}`);
});

// Создаем HTTP сервер
const server = http.createServer((req, res) => {
    proxy.web(req, res);
});

// Обработка WebSocket подключений
server.on('upgrade', (req, socket, head) => {
    proxy.ws(req, socket, head);
});

server.listen(PORT, () => {
    console.log(`Proxy server running on port ${PORT}`);
    console.log(`Forwarding all requests to ${TARGET_URL}`);
});
